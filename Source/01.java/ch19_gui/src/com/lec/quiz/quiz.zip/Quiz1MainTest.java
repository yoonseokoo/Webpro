package com.lec.quiz;

public class Quiz1MainTest {
	public static void main(String[] args) {
		new Quiz1_GUI("Test Example");
	}
}
